Shalom avi
ine program azbani im s0sim
run it,
try 10 hazir 50 kashe
ok ?


bye,
uri.